import { useState } from "react"
import { Plus, ShieldCheck, UserRound, UserRoundX } from "lucide-react"
import { api } from "../services/api"
import { useApi } from "../hooks/useApi"
import {
  Button,
  EmptyState,
  ErrorState,
  Field,
  Input,
  LoadingState,
  Modal,
  PageHeader,
  RoleBadge,
  Select,
  Toast,
} from "../components/ui"

export default function UsersPage() {
  const {
    data: users,
    setData: setUsers,
    error,
    loading,
    reload,
  } = useApi(() => api.getUsers(), [])
  const [modalOpen, setModalOpen] = useState(false)
  const [form, setForm] = useState({ name: "", email: "", role: "User" })
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState("")
  const [toast, setToast] = useState("")

  async function addUser(event) {
    event.preventDefault()
    if (!form.name.trim() || !form.email.trim())
      return setFormError("Name and email are required.")
    setSaving(true)
    try {
      const response = await api.createUser(form)
      setUsers((current) => [...current, response.data])
      setModalOpen(false)
      setForm({ name: "", email: "", role: "User" })
      setToast("User account added.")
    } catch (err) {
      setFormError(
        err.status === 403
          ? "Only administrators can manage users."
          : err.message,
      )
    } finally {
      setSaving(false)
    }
  }

  async function updateUser(user, values) {
    try {
      const response = await api.updateUser(user.id, values)
      setUsers((current) =>
        current.map((item) => (item.id === user.id ? response.data : item)),
      )
      setToast("User account updated.")
    } catch (err) {
      setToast(
        err.status === 403
          ? "You do not have permission to update users."
          : "Update failed. Please try again.",
      )
    }
  }

  return (
    <>
      <PageHeader
        eyebrow="Administrator access"
        title="User management"
        description="Add staff, assign roles, and control access to the inventory system."
        actions={
          <Button onClick={() => setModalOpen(true)}>
            <Plus size={17} />
            Add user
          </Button>
        }
      />
      <section className="panel users-panel">
        <div className="users-summary">
          <div>
            <span>
              <ShieldCheck size={19} />
            </span>
            <div>
              <strong>Role-based access</strong>
              <p>
                Admins manage records and users. Staff can add and view
                inventory.
              </p>
            </div>
          </div>
          <small>
            {users?.filter((user) => user.status === "Active").length || 0}{" "}
            active users
          </small>
        </div>
        {error ? (
          <ErrorState
            title={
              error.status === 403
                ? "Access restricted"
                : "Unable to load users"
            }
            message={error.message}
            onRetry={reload}
          />
        ) : loading ? (
          <LoadingState rows={4} />
        ) : !users?.length ? (
          <EmptyState
            title="No users yet"
            description="Add a staff member to get started."
          />
        ) : (
          <div className="table-scroll">
            <table className="data-table users-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id}>
                    <td>
                      <div className="user-cell">
                        <span>
                          <UserRound size={17} />
                        </span>
                        <strong>{user.name}</strong>
                      </div>
                    </td>
                    <td>{user.email}</td>
                    <td>
                      <Select
                        value={user.role}
                        onChange={(event) =>
                          updateUser(user, { role: event.target.value })
                        }
                      >
                        <option>Admin</option>
                        <option>User</option>
                      </Select>
                    </td>
                    <td>
                      <span
                        className={`account-status ${user.status.toLowerCase()}`}
                      >
                        <i />
                        {user.status}
                      </span>
                    </td>
                    <td>
                      <Button
                        variant="ghost"
                        onClick={() =>
                          updateUser(user, {
                            status:
                              user.status === "Active" ? "Inactive" : "Active",
                          })
                        }
                      >
                        {user.status === "Active" ? (
                          <>
                            <UserRoundX size={16} />
                            Deactivate
                          </>
                        ) : (
                          "Reactivate"
                        )}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Add a user"
        description="Create an account and choose the appropriate access level."
        footer={
          <>
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button loading={saving} onClick={addUser}>
              Add user
            </Button>
          </>
        }
      >
        <form className="modal-form" onSubmit={addUser}>
          {formError && <div className="inline-error">{formError}</div>}
          <Field label="Full name" required>
            <Input
              value={form.name}
              onChange={(event) =>
                setForm({ ...form, name: event.target.value })
              }
              placeholder="e.g. Alice Chebet"
            />
          </Field>
          <Field label="Email address" required>
            <Input
              type="email"
              value={form.email}
              onChange={(event) =>
                setForm({ ...form, email: event.target.value })
              }
              placeholder="name@gosrani.co.ke"
            />
          </Field>
          <Field label="Role" required>
            <Select
              value={form.role}
              onChange={(event) =>
                setForm({ ...form, role: event.target.value })
              }
            >
              <option>User</option>
              <option>Admin</option>
            </Select>
          </Field>
          <div className="role-explainer">
            <RoleBadge role={form.role} />
            <p>
              {form.role === "Admin"
                ? "Can manage inventory records, lock entries, and manage users."
                : "Can add and view records. Saved entries are locked."}
            </p>
          </div>
        </form>
      </Modal>
      <Toast message={toast} onClose={() => setToast("")} />
    </>
  )
}
