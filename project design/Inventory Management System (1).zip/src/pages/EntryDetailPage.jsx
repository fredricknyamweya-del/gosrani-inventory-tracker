import { useState } from "react"
import {
  AlertCircle,
  ArrowLeft,
  CalendarDays,
  Clock3,
  LockKeyhole,
  Pencil,
  Trash2,
  UserRound,
} from "lucide-react"
import { Link, useNavigate, useParams } from "react-router"
import { useApi } from "../hooks/useApi"
import { api } from "../services/api"
import { useAuth } from "../context/AuthContext"
import {
  Button,
  ErrorState,
  LoadingState,
  Modal,
  PageHeader,
  StatusBadge,
} from "../components/ui"
import { formatDate, formatDateTime } from "../utils/format"

export default function EntryDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { isAdmin } = useAuth()
  const {
    data: record,
    setData: setRecord,
    error,
    loading,
    reload,
  } = useApi(() => api.getInventoryById(id), [id])
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [locking, setLocking] = useState(false)
  const [deleteError, setDeleteError] = useState("")

  async function remove() {
    setDeleting(true)
    setDeleteError("")
    try {
      await api.deleteInventory(id)
      navigate("/inventory")
    } catch (err) {
      setDeleteError(
        err.status === 403
          ? "You do not have permission to delete this record."
          : err.message,
      )
    } finally {
      setDeleting(false)
    }
  }

  async function lockRecord() {
    setLocking(true)
    setDeleteError("")
    try {
      const response = await api.updateInventory(id, {
        ...record,
        status: "Locked",
      })
      setRecord(response.data)
    } catch (err) {
      setDeleteError(
        err.status === 403
          ? "You do not have permission to lock this record."
          : err.message,
      )
    } finally {
      setLocking(false)
    }
  }

  if (loading)
    return (
      <>
        <PageHeader title="Loading record…" />
        <section className="panel">
          <LoadingState rows={5} />
        </section>
      </>
    )
  if (error)
    return (
      <ErrorState
        title="Unable to load record"
        message={error.message}
        onRetry={reload}
      />
    )

  const details = [
    ["Date", formatDate(record.date)],
    ["Item", record.item],
    ["Size", record.size || "–"],
    ["Quantity In", record.quantityIn ?? "–", "qty-in"],
    ["Quantity Out", record.quantityOut ?? "–", "qty-out"],
    ["Details", record.details || "–"],
  ]

  return (
    <>
      <Link className="back-link" to="/inventory">
        <ArrowLeft size={16} />
        Back to inventory
      </Link>
      <PageHeader
        eyebrow={record.id}
        title={record.item}
        description={`${record.size || "No size"} · Inventory movement record`}
        actions={
          isAdmin ? (
            <>
              {record.status !== "Locked" && (
                <Button
                  variant="secondary"
                  loading={locking}
                  onClick={lockRecord}
                >
                  <LockKeyhole size={16} />
                  Lock
                </Button>
              )}
              <Link className="btn btn-secondary" to={`/inventory/${id}/edit`}>
                <Pencil size={16} />
                Edit
              </Link>
              <Button variant="destructive" onClick={() => setDeleteOpen(true)}>
                <Trash2 size={16} />
                Delete
              </Button>
            </>
          ) : null
        }
      />
      {!isAdmin && (
        <div className="locked-notice">
          <LockKeyhole size={19} />
          <div>
            <strong>Locked – contact Admin to change</strong>
            <p>Staff entries cannot be edited or deleted after confirmation.</p>
          </div>
        </div>
      )}
      <div className="detail-layout">
        <section className="panel detail-card">
          <div className="detail-card-head">
            <div>
              <h2>Entry details</h2>
              <p>Recorded stock movement information</p>
            </div>
            <StatusBadge status={record.status} />
          </div>
          <dl className="detail-grid">
            {details.map(([label, value, className]) => (
              <div
                key={label}
                className={label === "Details" ? "detail-wide" : ""}
              >
                <dt>{label}</dt>
                <dd className={className || ""}>{value}</dd>
              </div>
            ))}
          </dl>
        </section>
        <aside className="panel audit-card">
          <h2>Audit information</h2>
          <div className="audit-item">
            <span>
              <UserRound size={17} />
            </span>
            <div>
              <small>Created by</small>
              <strong>{record.addedBy}</strong>
            </div>
          </div>
          <div className="audit-item">
            <span>
              <CalendarDays size={17} />
            </span>
            <div>
              <small>Date / time created</small>
              <strong>{formatDateTime(record.createdAt)}</strong>
            </div>
          </div>
          <div className="audit-item">
            <span>
              <Clock3 size={17} />
            </span>
            <div>
              <small>Last modified by</small>
              <strong>{record.modifiedBy || record.addedBy}</strong>
            </div>
          </div>
          <div className="audit-id">
            <span>Record ID</span>
            <code>{record.id}</code>
          </div>
        </aside>
      </div>
      <Modal
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        title="Delete this record?"
        description="This action is permanent and cannot be undone."
        footer={
          <>
            <Button variant="secondary" onClick={() => setDeleteOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" loading={deleting} onClick={remove}>
              Delete record
            </Button>
          </>
        }
      >
        {deleteError && (
          <div className="inline-error">
            <AlertCircle size={17} />
            {deleteError}
          </div>
        )}
        <div className="delete-summary">
          <Trash2 size={20} />
          <p>
            Delete{" "}
            <strong>
              {record.item} · {record.size}
            </strong>{" "}
            dated {formatDate(record.date)}?
          </p>
        </div>
      </Modal>
    </>
  )
}
