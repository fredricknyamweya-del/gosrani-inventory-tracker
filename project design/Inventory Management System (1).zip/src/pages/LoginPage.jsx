import { useState } from "react"
import {
  ArrowRight,
  Eye,
  EyeOff,
  LockKeyhole,
  PackageCheck,
} from "lucide-react"
import { Navigate, useNavigate } from "react-router"
import { useAuth } from "../context/AuthContext"
import ThemeToggle from "../components/ThemeToggle"
import { Button, Field, Input } from "../components/ui"

export default function LoginPage() {
  const { user, login, loading } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: "", password: "" })
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")

  if (user) return <Navigate to="/inventory" replace />

  async function submit(event) {
    event.preventDefault()
    setError("")
    try {
      await login(form)
      navigate("/inventory")
    } catch (err) {
      setError(err.message)
    }
  }

  const fillDemo = (role) =>
    setForm({
      email: role === "Admin" ? "admin@gosrani.co.ke" : "staff@gosrani.co.ke",
      password: "demo1234",
    })

  return (
    <div className="login-page">
      <section className="login-brand-panel">
        <div className="login-brand">
          <div className="login-logo">
            <PackageCheck size={29} />
          </div>
          <div>
            <strong>Gosrani Wholesalers Limited</strong>
            <span>Eldoret, Kenya</span>
          </div>
        </div>
        <div className="login-statement">
          <span className="secure-pill">
            <LockKeyhole size={14} /> Secure inventory workspace
          </span>
          <h1>
            Stock records.
            <br />
            <em>Clear and reliable.</em>
          </h1>
          <p>
            A focused workspace for fast inventory entry, accurate review, and
            instant lookup.
          </p>
        </div>
        <div className="login-brand-footer">
          <span>GWL</span>
          <p>
            Trusted wholesale operations
            <br />
            in the heart of Eldoret.
          </p>
        </div>
      </section>
      <section className="login-form-panel">
        <div className="login-theme">
          <ThemeToggle />
        </div>
        <div className="login-form-wrap">
          <div className="mobile-login-brand">
            <div className="brand-mark">GW</div>
            <div>
              <strong>Gosrani Wholesalers Limited</strong>
              <span>Eldoret, Kenya</span>
            </div>
          </div>
          <div className="login-heading">
            <span>Welcome back</span>
            <h2>Sign in to your account</h2>
            <p>Enter your details to access the inventory system.</p>
          </div>
          {error && (
            <div className="login-error" role="alert">
              <span>!</span>
              <div>
                <strong>Unable to sign in</strong>
                <p>{error}</p>
              </div>
            </div>
          )}
          <form onSubmit={submit} className="login-form">
            <Field label="Email address" required>
              <Input
                type="email"
                value={form.email}
                onChange={(event) =>
                  setForm({ ...form, email: event.target.value })
                }
                placeholder="name@gosrani.co.ke"
                autoComplete="email"
                required
              />
            </Field>
            <Field label="Password" required>
              <div className="password-input">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={(event) =>
                    setForm({ ...form, password: event.target.value })
                  }
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((value) => !value)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </Field>
            <Button type="submit" loading={loading} className="login-submit">
              Sign in <ArrowRight size={18} />
            </Button>
          </form>
          <div className="demo-access">
            <span>Prototype access</span>
            <div>
              <button onClick={() => fillDemo("Admin")}>
                Use Admin account
              </button>
              <button onClick={() => fillDemo("User")}>
                Use Staff account
              </button>
            </div>
          </div>
          <p className="login-help">
            Need help accessing your account? Contact your administrator.
          </p>
        </div>
        <footer>© 2026 Gosrani Wholesalers Limited · Eldoret, Kenya</footer>
      </section>
    </div>
  )
}
