import { ShieldCheck, Sparkles } from "lucide-react"
import AssistantChat from "../components/AssistantChat"
import { PageHeader } from "../components/ui"

export default function AssistantPage() {
  return (
    <>
      <PageHeader
        eyebrow="Read-only search"
        title="AI Inventory Assistant"
        description="Ask natural-language questions and quickly find matching inventory records."
        actions={
          <span className="read-only-pill">
            <ShieldCheck size={16} />
            Read-only access
          </span>
        }
      />
      <section className="panel assistant-page-panel">
        <div className="assistant-page-head">
          <div className="assistant-icon">
            <Sparkles size={19} />
          </div>
          <div>
            <strong>Gosrani Inventory AI</strong>
            <span>Connected to inventory records</span>
          </div>
        </div>
        <AssistantChat />
      </section>
    </>
  )
}
