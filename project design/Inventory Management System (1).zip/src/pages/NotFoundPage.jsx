import { Link } from "react-router"
import { EmptyState } from "../components/ui"

export default function NotFoundPage() {
  return (
    <section className="panel">
      <EmptyState
        title="Page not found"
        description="The page you requested does not exist."
        action={
          <Link to="/inventory" className="btn btn-primary">
            Back to inventory
          </Link>
        }
      />
    </section>
  )
}
