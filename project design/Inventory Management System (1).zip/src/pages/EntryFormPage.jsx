import { useEffect, useMemo, useState } from "react"
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  CheckCircle2,
  Copy,
  ListPlus,
  Plus,
  RotateCcw,
  Save,
  Trash2,
} from "lucide-react"
import { Link, useNavigate, useParams } from "react-router"
import { api, inventoryCatalog } from "../services/api"
import { useAuth } from "../context/AuthContext"
import {
  Button,
  ErrorState,
  Field,
  Input,
  LoadingState,
  PageHeader,
  SuccessMark,
} from "../components/ui"
import { formatDate, todayIso } from "../utils/format"

const makeRow = () => ({
  date: todayIso(),
  item: "",
  size: "",
  quantityIn: "",
  quantityOut: "",
  details: "",
})

function validateRow(row) {
  const errors = {}
  if (!row.date) errors.date = "Date is required."
  if (!row.item.trim()) errors.item = "Item is required."
  if (row.quantityIn === "" && row.quantityOut === "")
    errors.quantity = "Enter at least one quantity."
  for (const key of ["quantityIn", "quantityOut"]) {
    if (
      row[key] !== "" &&
      (!Number.isInteger(Number(row[key])) || Number(row[key]) < 0)
    )
      errors[key] = "Use a whole, non-negative number."
  }
  return errors
}

export default function EntryFormPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user, isAdmin } = useAuth()
  const isEdit = Boolean(id)
  const [mode, setMode] = useState("single")
  const [rows, setRows] = useState([makeRow()])
  const [original, setOriginal] = useState(null)
  const [errors, setErrors] = useState([])
  const [stage, setStage] = useState("form")
  const [warnings, setWarnings] = useState([])
  const [verified, setVerified] = useState(false)
  const [loading, setLoading] = useState(isEdit)
  const [submitting, setSubmitting] = useState(false)
  const [pageError, setPageError] = useState(null)
  const [saved, setSaved] = useState([])

  useEffect(() => {
    if (!isEdit) return
    if (!isAdmin) {
      setPageError(
        Object.assign(
          new Error("Only administrators can edit saved records."),
          { status: 403 },
        ),
      )
      setLoading(false)
      return
    }
    api
      .getInventoryById(id)
      .then((response) => {
        const row = response.data
        const editable = {
          date: row.date,
          item: row.item,
          size: row.size,
          quantityIn: row.quantityIn ?? "",
          quantityOut: row.quantityOut ?? "",
          details: row.details,
        }
        setRows([editable])
        setOriginal(editable)
      })
      .catch(setPageError)
      .finally(() => setLoading(false))
  }, [id, isAdmin, isEdit])

  const update = (index, key, value) => {
    setRows((current) =>
      current.map((row, rowIndex) =>
        rowIndex === index ? { ...row, [key]: value } : row,
      ),
    )
    setErrors((current) =>
      current.map((row, rowIndex) =>
        rowIndex === index
          ? {
              ...row,
              [key]: "",
              ...(key.startsWith("quantity") ? { quantity: "" } : {}),
            }
          : row,
      ),
    )
  }

  const addRow = () => setRows((current) => [...current, makeRow()])
  const duplicateRow = () =>
    setRows((current) => [...current, { ...current.at(-1), details: "" }])
  const removeRow = (index) =>
    setRows((current) => current.filter((_, rowIndex) => rowIndex !== index))

  async function review(event) {
    event?.preventDefault()
    const nextErrors = rows.map(validateRow)
    setErrors(nextErrors)
    if (nextErrors.some((row) => Object.keys(row).length)) return
    setSubmitting(true)
    setPageError(null)
    try {
      const response = await api.validateInventory(rows)
      setWarnings(response.data.warnings)
      setRows(response.data.rows)
      setVerified(false)
      setStage("review")
      window.scrollTo({ top: 0, behavior: "smooth" })
    } catch (err) {
      setPageError(err)
    } finally {
      setSubmitting(false)
    }
  }

  async function save() {
    setSubmitting(true)
    setPageError(null)
    try {
      const response = isEdit
        ? await api.updateInventory(id, rows[0])
        : await api.createInventory(rows)
      setSaved(Array.isArray(response.data) ? response.data : [response.data])
      setStage("success")
    } catch (err) {
      setPageError(err)
    } finally {
      setSubmitting(false)
    }
  }

  function discard() {
    if (isEdit) navigate(`/inventory/${id}`)
    else {
      setRows([makeRow()])
      setStage("form")
      navigate("/inventory")
    }
  }

  if (loading)
    return (
      <>
        <PageHeader title="Loading entry…" />
        <section className="panel">
          <LoadingState rows={5} />
        </section>
      </>
    )
  if (pageError && stage === "form")
    return (
      <ErrorState
        title={
          pageError.status === 403
            ? "Access restricted"
            : "Unable to load entry"
        }
        message={pageError.message}
        onRetry={() => navigate("/inventory")}
      />
    )

  if (stage === "success") {
    return (
      <section className="success-page panel">
        <SuccessMark />
        <span className="eyebrow">Entry saved</span>
        <h1>
          {saved.length > 1
            ? `${saved.length} inventory entries saved`
            : "Inventory entry saved"}
        </h1>
        <p>
          Your {saved.length > 1 ? "records are" : "record is"} now available in
          the inventory list.{" "}
          {user.role === "User" &&
            "Saved entries are locked for staff accounts."}
        </p>
        <div className="saved-records">
          {saved.map((row) => (
            <div key={row.id}>
              <div>
                <strong>{row.item}</strong>
                <span>
                  {row.size || "No size"} · {formatDate(row.date)}
                </span>
              </div>
              <span className={`status status-${row.status.toLowerCase()}`}>
                {row.status}
              </span>
            </div>
          ))}
        </div>
        <div className="success-actions">
          <Link className="btn btn-secondary" to="/inventory">
            Back to inventory
          </Link>
          {saved.length === 1 && (
            <Link
              className="btn btn-secondary"
              to={`/inventory/${saved[0].id}`}
            >
              View record
            </Link>
          )}
          <Button
            onClick={() => {
              setRows([makeRow()])
              setStage("form")
              setSaved([])
            }}
          >
            <Plus size={17} />
            Add another
          </Button>
        </div>
      </section>
    )
  }

  if (stage === "review") {
    const totalWarnings = warnings.reduce(
      (count, row) => count + row.flags.length,
      0,
    )
    return (
      <>
        <PageHeader
          eyebrow={isEdit ? "Admin edit" : "Final check"}
          title={isEdit ? "Review your changes" : "Review your entry"}
          description="Nothing has been saved yet. Check every detail before confirming."
        />
        <div className="review-layout">
          <section className="panel review-panel">
            <div className="review-intro">
              <span className={totalWarnings ? "warning-icon" : "review-ok"}>
                {totalWarnings ? (
                  <AlertTriangle size={20} />
                ) : (
                  <Check size={20} />
                )}
              </span>
              <div>
                <strong>
                  {totalWarnings
                    ? `${totalWarnings} item${
                        totalWarnings > 1 ? "s" : ""
                      } need your attention`
                    : "Everything looks ready"}
                </strong>
                <p>
                  {totalWarnings
                    ? "Warnings do not block saving, but please verify them carefully."
                    : "Review the summary below, then confirm it is correct."}
                </p>
              </div>
            </div>
            {pageError && (
              <div className="save-error">
                <AlertTriangle size={20} />
                <div>
                  <strong>Save failed – your data is safe</strong>
                  <p>
                    {pageError.status === 403
                      ? "You do not have permission to save this change."
                      : "We could not save the entry. Please try again."}
                  </p>
                </div>
              </div>
            )}
            {isEdit && original && (
              <BeforeAfter original={original} updated={rows[0]} />
            )}
            <div className="review-table-scroll">
              <table className="review-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Date</th>
                    <th>Item</th>
                    <th>Size</th>
                    <th>Qty In</th>
                    <th>Qty Out</th>
                    <th>Details</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, index) => {
                    const flags = warnings[index]?.flags || []
                    const flagged = (field) =>
                      flags.some(
                        (flag) =>
                          flag.field === field ||
                          (flag.field === "quantity" &&
                            field.startsWith("quantity")),
                      )
                    return (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td className={flagged("date") ? "flagged" : ""}>
                          {formatDate(row.date)}
                        </td>
                        <td className={flagged("item") ? "flagged" : ""}>
                          {row.item}
                        </td>
                        <td className={flagged("size") ? "flagged" : ""}>
                          {row.size || "–"}
                        </td>
                        <td className={flagged("quantityIn") ? "flagged" : ""}>
                          {row.quantityIn ?? "–"}
                        </td>
                        <td className={flagged("quantityOut") ? "flagged" : ""}>
                          {row.quantityOut ?? "–"}
                        </td>
                        <td>{row.details || "–"}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
            {totalWarnings > 0 && (
              <div className="warning-list">
                {warnings.flatMap((item) =>
                  item.flags.map((flag, index) => (
                    <div key={`${item.index}-${index}`}>
                      <AlertTriangle size={16} />
                      <p>
                        <strong>Entry {item.index + 1}:</strong> {flag.message}
                      </p>
                    </div>
                  )),
                )}
              </div>
            )}
          </section>
          <aside className="panel confirm-card">
            <h2>Ready to save?</h2>
            <p>
              Once confirmed,{" "}
              {user.role === "User"
                ? "this entry will be locked and only an Admin can make changes."
                : "this entry will be added to inventory records."}
            </p>
            <label className="confirm-check">
              <input
                type="checkbox"
                checked={verified}
                onChange={(event) => setVerified(event.target.checked)}
              />
              <span>
                <Check size={14} />
              </span>
              <p>I have verified that this information is correct.</p>
            </label>
            <Button
              className="full-button"
              disabled={!verified}
              loading={submitting}
              onClick={save}
            >
              <Save size={17} />
              Confirm & Save
            </Button>
            <Button
              className="full-button"
              variant="secondary"
              onClick={() => {
                setStage("form")
                setPageError(null)
              }}
            >
              <ArrowLeft size={17} />
              Edit information
            </Button>
            <Button className="full-button" variant="ghost" onClick={discard}>
              Discard
            </Button>
            <div className="confirm-note">
              <CheckCircle2 size={17} />
              <span>Your data will only be saved after you confirm.</span>
            </div>
          </aside>
        </div>
      </>
    )
  }

  return (
    <>
      <PageHeader
        eyebrow={isEdit ? "Admin edit" : "New inventory record"}
        title={isEdit ? `Edit ${id}` : "Add inventory entry"}
        description={
          isEdit
            ? "Update the record, then review every change before saving."
            : "Record stock received or issued. You will review everything before it is saved."
        }
      />
      {!isEdit && (
        <div className="mode-switch" role="tablist">
          <button
            className={mode === "single" ? "active" : ""}
            onClick={() => {
              setMode("single")
              setRows([rows[0]])
            }}
          >
            <Plus size={17} />
            Single entry
          </button>
          <button
            className={mode === "multiple" ? "active" : ""}
            onClick={() => setMode("multiple")}
          >
            <ListPlus size={17} />
            Add multiple items
          </button>
        </div>
      )}
      <form onSubmit={review}>
        {mode === "single" || isEdit ? (
          <SingleForm
            row={rows[0]}
            errors={errors[0] || {}}
            update={(key, value) => update(0, key, value)}
          />
        ) : (
          <section className="panel multi-panel">
            <div className="multi-head">
              <div>
                <h2>Inventory items</h2>
                <p>Enter one stock movement per row.</p>
              </div>
              <Button type="button" variant="secondary" onClick={duplicateRow}>
                <Copy size={16} />
                Duplicate previous row
              </Button>
            </div>
            <div className="multi-scroll">
              <table className="multi-table">
                <thead>
                  <tr>
                    <th>Date *</th>
                    <th>Item *</th>
                    <th>Size</th>
                    <th>Quantity In</th>
                    <th>Quantity Out</th>
                    <th>Details</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, index) => (
                    <tr
                      key={index}
                      onKeyDown={(event) => {
                        if (
                          event.key === "Enter" &&
                          event.target.tagName !== "TEXTAREA"
                        ) {
                          event.preventDefault()
                          if (index === rows.length - 1) addRow()
                        }
                      }}
                    >
                      <td>
                        <Input
                          type="date"
                          value={row.date}
                          error={errors[index]?.date}
                          onChange={(event) =>
                            update(index, "date", event.target.value)
                          }
                        />
                        {errors[index]?.date && (
                          <small className="cell-error">
                            {errors[index].date}
                          </small>
                        )}
                      </td>
                      <td>
                        <Input
                          list="items"
                          value={row.item}
                          error={errors[index]?.item}
                          onChange={(event) =>
                            update(index, "item", event.target.value)
                          }
                          placeholder="Item name"
                        />
                        {errors[index]?.item && (
                          <small className="cell-error">
                            {errors[index].item}
                          </small>
                        )}
                      </td>
                      <td>
                        <Input
                          list="sizes"
                          value={row.size}
                          onChange={(event) =>
                            update(index, "size", event.target.value)
                          }
                          placeholder="Size"
                        />
                      </td>
                      <td>
                        <Input
                          type="number"
                          min="0"
                          step="1"
                          value={row.quantityIn ?? ""}
                          error={
                            errors[index]?.quantityIn || errors[index]?.quantity
                          }
                          onChange={(event) =>
                            update(index, "quantityIn", event.target.value)
                          }
                          placeholder="0"
                        />
                      </td>
                      <td>
                        <Input
                          type="number"
                          min="0"
                          step="1"
                          value={row.quantityOut ?? ""}
                          error={
                            errors[index]?.quantityOut ||
                            errors[index]?.quantity
                          }
                          onChange={(event) =>
                            update(index, "quantityOut", event.target.value)
                          }
                          placeholder="0"
                        />
                        {errors[index]?.quantity && (
                          <small className="cell-error">
                            {errors[index].quantity}
                          </small>
                        )}
                      </td>
                      <td>
                        <Input
                          value={row.details}
                          onChange={(event) =>
                            update(index, "details", event.target.value)
                          }
                          placeholder="Optional note"
                        />
                      </td>
                      <td>
                        <button
                          className="icon-btn danger-hover"
                          type="button"
                          disabled={rows.length === 1}
                          onClick={() => removeRow(index)}
                          title="Remove row"
                        >
                          <Trash2 size={17} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Button type="button" variant="secondary" onClick={addRow}>
              <Plus size={16} />
              Add row
            </Button>
          </section>
        )}
        <datalist id="items">
          {inventoryCatalog.items.map((item) => (
            <option value={item} key={item} />
          ))}
        </datalist>
        <datalist id="sizes">
          {inventoryCatalog.sizes.map((size) => (
            <option value={size} key={size} />
          ))}
        </datalist>
        <div className="form-actions">
          <Button type="button" variant="ghost" onClick={discard}>
            Cancel
          </Button>
          <Button type="submit" loading={submitting}>
            Review entry <ArrowLeft className="arrow-right" size={17} />
          </Button>
        </div>
      </form>
    </>
  )
}

function SingleForm({ row, errors, update }) {
  const future = row.date && row.date > todayIso()
  return (
    <section className="panel entry-form-panel">
      <div className="form-section-head">
        <span>01</span>
        <div>
          <h2>Stock movement</h2>
          <p>Enter the exact details from the source document.</p>
        </div>
      </div>
      <div className="form-grid">
        <Field
          label="Date"
          required
          error={errors.date}
          hint={
            future
              ? "This date is in the future. You can continue and review the warning."
              : "Displayed as DD/MM/YYYY when saved."
          }
        >
          <Input
            type="date"
            value={row.date}
            error={errors.date}
            onChange={(event) => update("date", event.target.value)}
          />
        </Field>
        <Field label="Item" required error={errors.item}>
          <Input
            list="items"
            value={row.item}
            error={errors.item}
            onChange={(event) => update("item", event.target.value)}
            placeholder="Search or enter item name"
          />
        </Field>
        <Field label="Size">
          <Input
            list="sizes"
            value={row.size}
            onChange={(event) => update("size", event.target.value)}
            placeholder="e.g. 2 kg"
          />
        </Field>
        <div className="quantity-group">
          <Field
            label="Quantity In"
            error={errors.quantityIn || errors.quantity}
          >
            <Input
              type="number"
              min="0"
              step="1"
              value={row.quantityIn ?? ""}
              error={errors.quantityIn || errors.quantity}
              onChange={(event) => update("quantityIn", event.target.value)}
              placeholder="0"
            />
          </Field>
          <div className="quantity-divider">or</div>
          <Field label="Quantity Out" error={errors.quantityOut}>
            <Input
              type="number"
              min="0"
              step="1"
              value={row.quantityOut ?? ""}
              error={errors.quantityOut}
              onChange={(event) => update("quantityOut", event.target.value)}
              placeholder="0"
            />
          </Field>
        </div>
        <Field
          label="Details"
          hint="Optional. Add a brief reference or reason for the movement."
          className="field-full"
        >
          <textarea
            className="input textarea"
            value={row.details}
            onChange={(event) => update("details", event.target.value)}
            placeholder="e.g. Supplier delivery, PO number, or dispatch destination"
            rows="4"
          />
        </Field>
      </div>
      <div className="form-safety">
        <CheckCircle2 size={18} />
        <p>
          <strong>You will review this entry before it is saved.</strong>
          <span>
            Use the next screen to catch typos, unusual values, or stock issues.
          </span>
        </p>
      </div>
    </section>
  )
}

function BeforeAfter({ original, updated }) {
  const labels = {
    date: "Date",
    item: "Item",
    size: "Size",
    quantityIn: "Quantity In",
    quantityOut: "Quantity Out",
    details: "Details",
  }
  const changes = Object.keys(labels).filter(
    (key) => String(original[key] ?? "") !== String(updated[key] ?? ""),
  )
  if (!changes.length)
    return (
      <div className="no-changes">
        <RotateCcw size={17} />
        No values have changed from the saved record.
      </div>
    )
  return (
    <div className="changes">
      <h3>Changed fields</h3>
      {changes.map((key) => (
        <div key={key}>
          <strong>{labels[key]}</strong>
          <span>
            {key === "date" ? formatDate(original[key]) : original[key] || "–"}
          </span>
          <b>→</b>
          <em>
            {key === "date" ? formatDate(updated[key]) : updated[key] || "–"}
          </em>
        </div>
      ))}
    </div>
  )
}
