import { useEffect, useState } from "react"
import {
  ChevronLeft,
  ChevronRight,
  Eye,
  Filter,
  LockKeyhole,
  Pencil,
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
} from "lucide-react"
import { Link, useSearchParams } from "react-router"
import { api, inventoryCatalog } from "../services/api"
import { useAuth } from "../context/AuthContext"
import {
  Button,
  EmptyState,
  ErrorState,
  LoadingState,
  Modal,
  PageHeader,
  Select,
  StatusBadge,
  Toast,
} from "../components/ui"
import { formatDate } from "../utils/format"

export default function InventoryPage() {
  const { isAdmin } = useAuth()
  const [searchParams] = useSearchParams()
  const [rows, setRows] = useState([])
  const [meta, setMeta] = useState({ page: 1, pages: 1, total: 0 })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [showFilters, setShowFilters] = useState(false)
  const [deleteRow, setDeleteRow] = useState(null)
  const [deleting, setDeleting] = useState(false)
  const [toast, setToast] = useState("")
  const [filters, setFilters] = useState({
    search: searchParams.get("search") || "",
    item: "",
    size: "",
    from: "",
    to: "",
    sort: "desc",
    page: 1,
  })

  useEffect(() => {
    setFilters((current) => ({
      ...current,
      search: searchParams.get("search") || "",
      page: 1,
    }))
  }, [searchParams])

  useEffect(() => {
    let current = true
    setLoading(true)
    setError(null)
    api
      .getInventory(filters)
      .then((response) => {
        if (current) {
          setRows(response.data)
          setMeta(response.meta)
        }
      })
      .catch((err) => current && setError(err))
      .finally(() => current && setLoading(false))
    return () => {
      current = false
    }
  }, [filters])

  const updateFilter = (key, value) =>
    setFilters((current) => ({
      ...current,
      [key]: value,
      page: key === "page" ? value : 1,
    }))
  const hasFilters =
    filters.item || filters.size || filters.from || filters.to || filters.search

  async function confirmDelete() {
    setDeleting(true)
    try {
      await api.deleteInventory(deleteRow.id)
      setDeleteRow(null)
      setToast("Inventory record deleted.")
      setFilters((current) => ({ ...current }))
    } catch (err) {
      setError(err)
      setDeleteRow(null)
    } finally {
      setDeleting(false)
    }
  }

  return (
    <>
      <PageHeader
        eyebrow="Inventory workspace"
        title="Inventory records"
        description="Search, review, and manage all stock movement records."
        actions={
          <Link className="btn btn-primary" to="/inventory/new">
            <Plus size={17} />
            Add entry
          </Link>
        }
      />
      <section className="panel inventory-panel">
        <div className="table-toolbar">
          <div className="table-search">
            <Search size={18} />
            <input
              value={filters.search}
              onChange={(event) => updateFilter("search", event.target.value)}
              placeholder="Search item, size, details, or staff…"
            />
          </div>
          <div className="toolbar-actions">
            <Button
              variant={
                showFilters || hasFilters ? "filter-active" : "secondary"
              }
              onClick={() => setShowFilters((value) => !value)}
            >
              <SlidersHorizontal size={17} />
              Filters{hasFilters && <i />}
            </Button>
            <Select
              aria-label="Sort records"
              value={filters.sort}
              onChange={(event) => updateFilter("sort", event.target.value)}
            >
              <option value="desc">Newest first</option>
              <option value="asc">Oldest first</option>
            </Select>
          </div>
        </div>
        {showFilters && (
          <div className="filters-bar">
            <div>
              <label>Item</label>
              <Select
                value={filters.item}
                onChange={(event) => updateFilter("item", event.target.value)}
              >
                <option value="">All items</option>
                {inventoryCatalog.items.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </Select>
            </div>
            <div>
              <label>Size</label>
              <Select
                value={filters.size}
                onChange={(event) => updateFilter("size", event.target.value)}
              >
                <option value="">All sizes</option>
                {inventoryCatalog.sizes.map((size) => (
                  <option key={size}>{size}</option>
                ))}
              </Select>
            </div>
            <div>
              <label>From date</label>
              <input
                className="input"
                type="date"
                value={filters.from}
                onChange={(event) => updateFilter("from", event.target.value)}
              />
            </div>
            <div>
              <label>To date</label>
              <input
                className="input"
                type="date"
                value={filters.to}
                onChange={(event) => updateFilter("to", event.target.value)}
              />
            </div>
            <Button
              variant="ghost"
              onClick={() =>
                setFilters({
                  search: "",
                  item: "",
                  size: "",
                  from: "",
                  to: "",
                  sort: "desc",
                  page: 1,
                })
              }
            >
              Clear all
            </Button>
          </div>
        )}
        {error ? (
          <ErrorState
            message={
              error.status === 403
                ? "You do not have permission to perform this action."
                : error.message
            }
            onRetry={() => setFilters((current) => ({ ...current }))}
          />
        ) : loading ? (
          <LoadingState rows={6} />
        ) : !rows.length ? (
          <EmptyState
            title="No inventory records found"
            description={
              hasFilters
                ? "Try changing or clearing your search filters."
                : "Add your first inventory entry to get started."
            }
            action={
              <Button
                variant="secondary"
                onClick={() =>
                  setFilters({
                    search: "",
                    item: "",
                    size: "",
                    from: "",
                    to: "",
                    sort: "desc",
                    page: 1,
                  })
                }
              >
                {hasFilters ? "Clear filters" : "Add entry"}
              </Button>
            }
          />
        ) : (
          <>
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Item</th>
                    <th>Size</th>
                    <th className="num">Qty In</th>
                    <th className="num">Qty Out</th>
                    <th>Details</th>
                    <th>Added By</th>
                    <th>Status</th>
                    <th>
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.id}>
                      <td className="nowrap">{formatDate(row.date)}</td>
                      <td>
                        <strong>{row.item}</strong>
                        <small>{row.id}</small>
                      </td>
                      <td>{row.size || "–"}</td>
                      <td className="num qty-in">{row.quantityIn ?? "–"}</td>
                      <td className="num qty-out">{row.quantityOut ?? "–"}</td>
                      <td className="details-cell" title={row.details}>
                        {row.details || "–"}
                      </td>
                      <td>{row.addedBy}</td>
                      <td>
                        <div className="status-cell">
                          <StatusBadge status={row.status} />
                          {!isAdmin && (
                            <span
                              className="lock-tip"
                              title="Locked – contact Admin to change"
                            >
                              <LockKeyhole size={14} />
                            </span>
                          )}
                        </div>
                      </td>
                      <td>
                        <div className="row-actions">
                          <Link
                            className="icon-btn"
                            to={`/inventory/${row.id}`}
                            title="View record"
                          >
                            <Eye size={17} />
                          </Link>
                          {isAdmin && (
                            <>
                              <Link
                                className="icon-btn"
                                to={`/inventory/${row.id}/edit`}
                                title="Edit record"
                              >
                                <Pencil size={16} />
                              </Link>
                              <button
                                className="icon-btn danger-hover"
                                onClick={() => setDeleteRow(row)}
                                title="Delete record"
                              >
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="table-footer">
              <span>
                Showing {(meta.page - 1) * 6 + 1}–
                {Math.min(meta.page * 6, meta.total)} of {meta.total} records
              </span>
              <div className="pagination">
                <button
                  disabled={meta.page <= 1}
                  onClick={() => updateFilter("page", meta.page - 1)}
                >
                  <ChevronLeft size={17} />
                </button>
                {Array.from({ length: meta.pages }).map((_, index) => (
                  <button
                    key={index}
                    className={meta.page === index + 1 ? "current" : ""}
                    onClick={() => updateFilter("page", index + 1)}
                  >
                    {index + 1}
                  </button>
                ))}
                <button
                  disabled={meta.page >= meta.pages}
                  onClick={() => updateFilter("page", meta.page + 1)}
                >
                  <ChevronRight size={17} />
                </button>
              </div>
            </div>
          </>
        )}
      </section>
      <Modal
        open={Boolean(deleteRow)}
        onClose={() => setDeleteRow(null)}
        title="Delete inventory record?"
        description="This action cannot be undone."
        footer={
          <>
            <Button variant="secondary" onClick={() => setDeleteRow(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              loading={deleting}
              onClick={confirmDelete}
            >
              Delete record
            </Button>
          </>
        }
      >
        <div className="delete-summary">
          <Trash2 size={20} />
          <p>
            You are about to permanently delete{" "}
            <strong>
              {deleteRow?.item} · {deleteRow?.size}
            </strong>{" "}
            from {formatDate(deleteRow?.date)}.
          </p>
        </div>
      </Modal>
      <Toast message={toast} onClose={() => setToast("")} />
    </>
  )
}
