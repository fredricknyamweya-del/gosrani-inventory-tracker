const wait = (ms = 450) => new Promise((resolve) => setTimeout(resolve, ms))

const seedRecords = [
  {
    id: "INV-1048",
    date: "2026-03-10",
    item: "Maize Flour",
    size: "2 kg",
    quantityIn: 240,
    quantityOut: null,
    details: "Received from main supplier",
    addedBy: "Grace Wanjiku",
    createdAt: "2026-03-10T08:42:00",
    modifiedBy: "Grace Wanjiku",
    status: "Locked",
  },
  {
    id: "INV-1047",
    date: "2026-03-09",
    item: "Cooking Oil",
    size: "1 L",
    quantityIn: null,
    quantityOut: 48,
    details: "Dispatch to Annex branch",
    addedBy: "Samuel Kiptoo",
    createdAt: "2026-03-09T15:18:00",
    modifiedBy: "Samuel Kiptoo",
    status: "Locked",
  },
  {
    id: "INV-1046",
    date: "2026-03-09",
    item: "White Sugar",
    size: "1 kg",
    quantityIn: 120,
    quantityOut: null,
    details: "PO 416 delivery",
    addedBy: "Grace Wanjiku",
    createdAt: "2026-03-09T10:05:00",
    modifiedBy: "Grace Wanjiku",
    status: "Saved",
  },
  {
    id: "INV-1045",
    date: "2026-03-08",
    item: "Bar Soap",
    size: "800 g",
    quantityIn: null,
    quantityOut: 36,
    details: "Counter sales",
    addedBy: "Daniel Otieno",
    createdAt: "2026-03-08T16:32:00",
    modifiedBy: "Daniel Otieno",
    status: "Locked",
  },
  {
    id: "INV-1044",
    date: "2026-03-07",
    item: "Rice",
    size: "5 kg",
    quantityIn: 80,
    quantityOut: null,
    details: "Weekly restock",
    addedBy: "Samuel Kiptoo",
    createdAt: "2026-03-07T09:21:00",
    modifiedBy: "Samuel Kiptoo",
    status: "Saved",
  },
  {
    id: "INV-1043",
    date: "2026-03-06",
    item: "Wheat Flour",
    size: "2 kg",
    quantityIn: null,
    quantityOut: 75,
    details: "Wholesale order 0981",
    addedBy: "Grace Wanjiku",
    createdAt: "2026-03-06T13:12:00",
    modifiedBy: "Grace Wanjiku",
    status: "Locked",
  },
  {
    id: "INV-1042",
    date: "2026-03-05",
    item: "Cooking Oil",
    size: "5 L",
    quantityIn: 60,
    quantityOut: null,
    details: "Supplier delivery",
    addedBy: "Daniel Otieno",
    createdAt: "2026-03-05T11:47:00",
    modifiedBy: "Daniel Otieno",
    status: "Saved",
  },
  {
    id: "INV-1041",
    date: "2026-03-04",
    item: "Maize Flour",
    size: "1 kg",
    quantityIn: 300,
    quantityOut: 24,
    details: "Opening balance adjustment",
    addedBy: "Grace Wanjiku",
    createdAt: "2026-03-04T08:10:00",
    modifiedBy: "Admin User",
    status: "Locked",
  },
  {
    id: "INV-1040",
    date: "2026-03-03",
    item: "Salt",
    size: "500 g",
    quantityIn: 180,
    quantityOut: null,
    details: "Monthly restock",
    addedBy: "Samuel Kiptoo",
    createdAt: "2026-03-03T14:24:00",
    modifiedBy: "Samuel Kiptoo",
    status: "Saved",
  },
]

const seedUsers = [
  {
    id: 1,
    name: "Admin User",
    email: "admin@gosrani.co.ke",
    role: "Admin",
    status: "Active",
  },
  {
    id: 2,
    name: "Grace Wanjiku",
    email: "grace@gosrani.co.ke",
    role: "User",
    status: "Active",
  },
  {
    id: 3,
    name: "Samuel Kiptoo",
    email: "samuel@gosrani.co.ke",
    role: "User",
    status: "Active",
  },
  {
    id: 4,
    name: "Daniel Otieno",
    email: "daniel@gosrani.co.ke",
    role: "User",
    status: "Inactive",
  },
]

let records = [...seedRecords]
let users = [...seedUsers]
let activeUser = null

const ok = (data, meta) => ({ data, ...(meta ? { meta } : {}) })
const fail = (status, message) => {
  const error = new Error(message)
  error.status = status
  throw error
}

function ensureAdmin() {
  if (activeUser?.role !== "Admin")
    fail(403, "This action is available to administrators only.")
}

function normalizeRecord(row) {
  return {
    date: row.date,
    item: row.item.trim(),
    size: row.size?.trim() || "",
    quantityIn:
      row.quantityIn === "" || row.quantityIn == null
        ? null
        : Number(row.quantityIn),
    quantityOut:
      row.quantityOut === "" || row.quantityOut == null
        ? null
        : Number(row.quantityOut),
    details: row.details?.trim() || "",
  }
}

export const api = {
  async login(credentials) {
    await wait(650)
    if (
      !credentials.email ||
      !credentials.password ||
      credentials.password === "wrong"
    ) {
      fail(401, "The email or password you entered is incorrect.")
    }
    const isAdmin = credentials.email.toLowerCase().includes("admin")
    activeUser = isAdmin
      ? { id: 1, name: "Admin User", email: credentials.email, role: "Admin" }
      : { id: 2, name: "Grace Wanjiku", email: credentials.email, role: "User" }
    return ok({ token: `mock-jwt-${activeUser.id}`, user: activeUser })
  },

  async me() {
    await wait(150)
    if (!activeUser) fail(401, "Your session has expired.")
    return ok(activeUser)
  },

  logout() {
    activeUser = null
  },

  setActiveUser(user) {
    activeUser = user
  },

  async getInventory(params = {}) {
    await wait()
    let result = [...records]
    const query = params.search?.toLowerCase()
    if (query)
      result = result.filter((row) =>
        [row.item, row.size, row.details, row.addedBy].some((value) =>
          value?.toLowerCase().includes(query),
        ),
      )
    if (params.item) result = result.filter((row) => row.item === params.item)
    if (params.size) result = result.filter((row) => row.size === params.size)
    if (params.from) result = result.filter((row) => row.date >= params.from)
    if (params.to) result = result.filter((row) => row.date <= params.to)
    result.sort((a, b) =>
      params.sort === "asc"
        ? a.date.localeCompare(b.date)
        : b.date.localeCompare(a.date),
    )
    const page = Number(params.page || 1)
    const limit = Number(params.limit || 6)
    const start = (page - 1) * limit
    return ok(result.slice(start, start + limit), {
      page,
      limit,
      total: result.length,
      pages: Math.max(1, Math.ceil(result.length / limit)),
    })
  },

  async getInventoryById(id) {
    await wait(320)
    const record = records.find((row) => row.id === id)
    if (!record) fail(404, "Inventory record not found.")
    return ok(record)
  },

  async validateInventory(input) {
    await wait(600)
    const rows = (Array.isArray(input) ? input : [input]).map(normalizeRecord)
    const knownItems = new Set(records.map((row) => row.item.toLowerCase()))
    const knownSizes = new Set(records.map((row) => row.size.toLowerCase()))
    const today = new Date()
    const warnings = rows.map((row, index) => {
      const flags = []
      if ((row.quantityIn || 0) >= 500 || (row.quantityOut || 0) >= 500)
        flags.push({
          field: "quantity",
          message:
            "Unusually large quantity. Check that the units are correct.",
        })
      if (row.quantityIn != null && row.quantityOut != null)
        flags.push({
          field: "quantity",
          message: "Both Quantity In and Quantity Out have values.",
        })
      if ((row.quantityOut || 0) > 250)
        flags.push({
          field: "quantityOut",
          message:
            "Quantity Out may exceed available stock for this item and size.",
        })
      const date = new Date(`${row.date}T00:00:00`)
      const days = Math.round((date - today) / 86400000)
      if (days > 0)
        flags.push({ field: "date", message: "This date is in the future." })
      if (days < -180)
        flags.push({
          field: "date",
          message: "This date is more than six months in the past.",
        })
      if (!knownItems.has(row.item.toLowerCase()))
        flags.push({
          field: "item",
          message:
            "This item does not match an existing item. Check for a typo.",
        })
      if (row.size && !knownSizes.has(row.size.toLowerCase()))
        flags.push({
          field: "size",
          message: "This size has not been used before. Check for a typo.",
        })
      return { index, flags }
    })
    return ok({ rows, warnings })
  },

  async createInventory(input) {
    await wait(700)
    const rows = (Array.isArray(input) ? input : [input]).map(normalizeRecord)
    const created = rows.map((row, index) => ({
      ...row,
      id: `INV-${1049 + records.length + index}`,
      addedBy: activeUser?.name || "Current User",
      createdAt: new Date().toISOString(),
      modifiedBy: activeUser?.name || "Current User",
      status: activeUser?.role === "Admin" ? "Saved" : "Locked",
    }))
    records = [...created, ...records]
    return ok(created)
  },

  async updateInventory(id, input) {
    await wait(650)
    ensureAdmin()
    const index = records.findIndex((row) => row.id === id)
    if (index < 0) fail(404, "Inventory record not found.")
    records[index] = {
      ...records[index],
      ...normalizeRecord(input),
      modifiedBy: activeUser.name,
      status: input.status || "Saved",
    }
    return ok(records[index])
  },

  async deleteInventory(id) {
    await wait(500)
    ensureAdmin()
    records = records.filter((row) => row.id !== id)
    return ok({ id })
  },

  async assistantQuery(question) {
    await wait(950)
    if (!question.trim()) fail(422, "Ask a question first.")
    const lower = question.toLowerCase()
    let result = records
      .filter((row) => {
        const text = `${row.item} ${row.size} ${row.details}`.toLowerCase()
        return lower
          .split(/\s+/)
          .some((word) => word.length > 3 && text.includes(word))
      })
      .slice(0, 4)
    if (lower.includes("yesterday") || lower.includes("went out"))
      result = records.filter((row) => row.quantityOut).slice(0, 4)
    if (lower.includes("received") || lower.includes("quantity in"))
      result = records.filter((row) => row.quantityIn).slice(0, 4)
    if (!result.length && !lower.includes("zzzz")) result = records.slice(0, 3)
    return ok({
      answer: result.length
        ? `I found ${result.length} matching inventory ${
            result.length === 1 ? "record" : "records"
          }.`
        : "I could not find any records matching that request.",
      records: result,
    })
  },

  async getUsers() {
    await wait()
    ensureAdmin()
    return ok(users)
  },

  async createUser(input) {
    await wait(550)
    ensureAdmin()
    const user = { id: Date.now(), ...input, status: "Active" }
    users = [...users, user]
    return ok(user)
  },

  async updateUser(id, input) {
    await wait(450)
    ensureAdmin()
    users = users.map((user) => (user.id === id ? { ...user, ...input } : user))
    return ok(users.find((user) => user.id === id))
  },
}

export const inventoryCatalog = {
  items: [
    "Bar Soap",
    "Cooking Oil",
    "Maize Flour",
    "Rice",
    "Salt",
    "Wheat Flour",
    "White Sugar",
  ],
  sizes: ["500 g", "800 g", "1 kg", "2 kg", "5 kg", "1 L", "5 L"],
}
