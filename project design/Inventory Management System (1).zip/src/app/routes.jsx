import { Navigate, createBrowserRouter } from "react-router"
import AppLayout from "../components/AppLayout"
import { useAuth } from "../context/AuthContext"
import LoginPage from "../pages/LoginPage"
import InventoryPage from "../pages/InventoryPage"
import EntryFormPage from "../pages/EntryFormPage"
import EntryDetailPage from "../pages/EntryDetailPage"
import AssistantPage from "../pages/AssistantPage"
import UsersPage from "../pages/UsersPage"
import NotFoundPage from "../pages/NotFoundPage"

function ProtectedRoute() {
  const { user } = useAuth()
  return user ? <AppLayout /> : <Navigate to="/login" replace />
}

function AdminRoute() {
  const { isAdmin } = useAuth()
  return isAdmin ? <UsersPage /> : <Navigate to="/inventory" replace />
}

export const router = createBrowserRouter([
  { path: "/login", Component: LoginPage },
  {
    path: "/",
    Component: ProtectedRoute,
    children: [
      { index: true, element: <Navigate to="/inventory" replace /> },
      { path: "inventory", Component: InventoryPage },
      { path: "inventory/new", Component: EntryFormPage },
      { path: "inventory/:id", Component: EntryDetailPage },
      { path: "inventory/:id/edit", Component: EntryFormPage },
      { path: "assistant", Component: AssistantPage },
      { path: "users", Component: AdminRoute },
      { path: "*", Component: NotFoundPage },
    ],
  },
])
