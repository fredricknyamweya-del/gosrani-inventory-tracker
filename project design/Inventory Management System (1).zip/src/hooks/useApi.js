import { useCallback, useEffect, useState } from "react"

export function useApi(request, dependencies = []) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(true)

  const run = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await request()
      setData(response.data)
      return response
    } catch (err) {
      setError(err)
    } finally {
      setLoading(false)
    }
  }, dependencies)

  useEffect(() => {
    run()
  }, [run])

  return { data, setData, error, loading, reload: run }
}
