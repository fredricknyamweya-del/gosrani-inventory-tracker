import { useState } from "react"
import { ArrowUp, Bot, ExternalLink, Sparkles } from "lucide-react"
import { Link } from "react-router"
import { api } from "../services/api"
import { Button, ErrorState } from "./ui"
import { formatDate } from "../utils/format"

export const suggestions = [
  "How much Maize Flour in size 2 kg is currently in stock?",
  "Show everything received this week",
  "What went out yesterday?",
  "Show all entries for Cooking Oil",
  "Find entries where the details mention supplier",
]

export default function AssistantChat({ compact = false, onNavigate }) {
  const [messages, setMessages] = useState([])
  const [question, setQuestion] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  async function send(value = question) {
    if (!value.trim() || loading) return
    const userMessage = { id: Date.now(), type: "user", text: value }
    setMessages((current) => [...current, userMessage])
    setQuestion("")
    setLoading(true)
    setError(null)
    try {
      const response = await api.assistantQuery(value)
      setMessages((current) => [
        ...current,
        { id: Date.now() + 1, type: "assistant", ...response.data },
      ])
    } catch (err) {
      setError(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={`assistant-chat ${compact ? "assistant-compact" : ""}`}>
      <div className="chat-scroll" aria-live="polite">
        {!messages.length && !error && (
          <div className="assistant-empty">
            <div className="assistant-orb">
              <Sparkles size={25} />
            </div>
            <h2>What would you like to find?</h2>
            <p>
              Ask a plain-language question about inventory records. I can look
              things up, but I cannot change any data.
            </p>
            <div className="suggestion-list">
              {suggestions.slice(0, compact ? 3 : 5).map((prompt) => (
                <button key={prompt} onClick={() => send(prompt)}>
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="message-list">
          {messages.map((message) =>
            message.type === "user" ? (
              <div className="message message-user" key={message.id}>
                <div className="bubble">{message.text}</div>
              </div>
            ) : (
              <div className="message message-assistant" key={message.id}>
                <div className="bot-avatar">
                  <Bot size={17} />
                </div>
                <div className="assistant-answer">
                  <p>{message.answer}</p>
                  {message.records?.length > 0 && (
                    <div className="chat-results">
                      {message.records.map((row) => (
                        <div className="chat-result" key={row.id}>
                          <div>
                            <strong>{row.item}</strong>
                            <span>
                              {row.size} · {formatDate(row.date)}
                            </span>
                          </div>
                          <div className="chat-qty">
                            <span className="qty-in">
                              {row.quantityIn ? `+${row.quantityIn}` : "–"}
                            </span>
                            <span className="qty-out">
                              {row.quantityOut ? `−${row.quantityOut}` : "–"}
                            </span>
                          </div>
                          <Link
                            to={`/inventory/${row.id}`}
                            onClick={onNavigate}
                            aria-label={`View ${row.id}`}
                          >
                            <ExternalLink size={15} />
                          </Link>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ),
          )}
          {loading && (
            <div className="message message-assistant">
              <div className="bot-avatar">
                <Bot size={17} />
              </div>
              <div className="thinking">
                <i />
                <i />
                <i />
                <span>Looking through inventory…</span>
              </div>
            </div>
          )}
        </div>
        {error && (
          <ErrorState
            title="Assistant unavailable"
            message="I couldn't complete that request. Please try again."
            onRetry={() => send(messages.at(-1)?.text || question)}
          />
        )}
      </div>
      <div className="chat-composer-wrap">
        <form
          className="chat-composer"
          onSubmit={(event) => {
            event.preventDefault()
            send()
          }}
        >
          <input
            value={question}
            onChange={(event) => setQuestion(event.target.value)}
            placeholder="Ask about your inventory…"
            aria-label="Ask the inventory assistant"
          />
          <Button
            type="submit"
            disabled={!question.trim() || loading}
            aria-label="Send message"
          >
            <ArrowUp size={18} />
          </Button>
        </form>
        <p>AI can make mistakes – verify important details in the record.</p>
      </div>
    </div>
  )
}
