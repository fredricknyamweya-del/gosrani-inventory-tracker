import { useState } from "react"
import { NavLink, Outlet, useLocation, useNavigate } from "react-router"
import {
  Bot,
  Boxes,
  ChevronDown,
  LogOut,
  Menu,
  Plus,
  Search,
  Sparkles,
  UserRoundCog,
  X,
} from "lucide-react"
import { useAuth } from "../context/AuthContext"
import { RoleBadge } from "./ui"
import ThemeToggle from "./ThemeToggle"
import AssistantChat from "./AssistantChat"

const navItems = [
  { to: "/inventory", label: "Inventory", icon: Boxes },
  { to: "/inventory/new", label: "Add Entry", icon: Plus },
  { to: "/assistant", label: "AI Assistant", icon: Sparkles },
]

export default function AppLayout() {
  const { user, logout, isAdmin } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [assistantOpen, setAssistantOpen] = useState(false)
  const [search, setSearch] = useState("")

  function submitSearch(event) {
    event.preventDefault()
    navigate(`/inventory?search=${encodeURIComponent(search)}`)
  }

  const closeMobile = () => setMobileOpen(false)

  return (
    <div className="app-shell">
      {mobileOpen && (
        <button
          className="mobile-scrim"
          onClick={closeMobile}
          aria-label="Close navigation"
        />
      )}
      <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
        <div className="sidebar-brand">
          <div className="brand-mark">GW</div>
          <div>
            <strong>Gosrani Wholesalers</strong>
            <span>Limited</span>
          </div>
          <button
            className="sidebar-close"
            onClick={closeMobile}
            aria-label="Close navigation"
          >
            <X size={20} />
          </button>
        </div>
        <nav className="sidebar-nav" aria-label="Main navigation">
          <span className="nav-label">Workspace</span>
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              onClick={closeMobile}
              className={({ isActive }) =>
                `nav-item ${
                  isActive &&
                  (to !== "/inventory" || location.pathname === "/inventory")
                    ? "active"
                    : ""
                }`
              }
            >
              <Icon size={19} />
              <span>{label}</span>
            </NavLink>
          ))}
          {isAdmin && (
            <NavLink
              to="/users"
              onClick={closeMobile}
              className={({ isActive }) =>
                `nav-item ${isActive ? "active" : ""}`
              }
            >
              <UserRoundCog size={19} />
              <span>User Management</span>
            </NavLink>
          )}
        </nav>
        <div className="sidebar-help">
          <Bot size={20} />
          <strong>Need a quick answer?</strong>
          <p>Ask the AI assistant to find any inventory record.</p>
          <button onClick={() => setAssistantOpen(true)}>Open assistant</button>
        </div>
        <div className="sidebar-foot">
          <span>Gosrani Wholesalers Limited</span>
          <small>Eldoret, Kenya</small>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <button
            className="menu-button"
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation"
          >
            <Menu size={21} />
          </button>
          <form className="global-search" onSubmit={submitSearch}>
            <Search size={18} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search inventory…"
              aria-label="Global inventory search"
            />
            <kbd>⌘ K</kbd>
          </form>
          <div className="topbar-actions">
            <button
              className="assistant-trigger"
              onClick={() => setAssistantOpen(true)}
            >
              <Sparkles size={17} />
              <span>Ask AI</span>
            </button>
            <ThemeToggle />
            <div className="profile-wrap">
              <button
                className="profile-button"
                onClick={() => setProfileOpen((value) => !value)}
                aria-expanded={profileOpen}
              >
                <span className="avatar">
                  {user?.name
                    ?.split(" ")
                    .map((part) => part[0])
                    .join("")
                    .slice(0, 2)}
                </span>
                <span className="profile-copy">
                  <strong>{user?.name}</strong>
                  <RoleBadge role={user?.role} />
                </span>
                <ChevronDown size={16} />
              </button>
              {profileOpen && (
                <div className="profile-menu">
                  <div>
                    <strong>{user?.name}</strong>
                    <span>{user?.email}</span>
                  </div>
                  <button
                    onClick={() => {
                      logout()
                      navigate("/login")
                    }}
                  >
                    <LogOut size={17} />
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>
        <main className="page-content" id="main-content">
          <Outlet />
        </main>
        <footer className="app-footer">
          Gosrani Wholesalers Limited, Eldoret, Kenya
        </footer>
      </div>

      {assistantOpen && (
        <>
          <button
            className="panel-scrim"
            onClick={() => setAssistantOpen(false)}
            aria-label="Close assistant"
          />
          <aside className="assistant-panel">
            <header>
              <div>
                <span>
                  <Sparkles size={17} />
                </span>
                <div>
                  <strong>Inventory Assistant</strong>
                  <small>Read-only access</small>
                </div>
              </div>
              <button
                onClick={() => setAssistantOpen(false)}
                aria-label="Close assistant"
              >
                <X size={20} />
              </button>
            </header>
            <AssistantChat compact onNavigate={() => setAssistantOpen(false)} />
          </aside>
        </>
      )}
    </div>
  )
}
