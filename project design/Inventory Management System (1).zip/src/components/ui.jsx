import { AlertCircle, Check, Inbox, LoaderCircle, X } from "lucide-react"

export function Button({
  variant = "primary",
  loading,
  className = "",
  children,
  ...props
}) {
  return (
    <button
      className={`btn btn-${variant} ${className}`}
      disabled={loading || props.disabled}
      {...props}
    >
      {loading ? <LoaderCircle size={17} className="spin" /> : children}
    </button>
  )
}

export function Field({
  label,
  error,
  hint,
  required,
  children,
  className = "",
}) {
  return (
    <label className={`field ${className}`}>
      <span className="field-label">
        {label}
        {required && <span aria-hidden="true"> *</span>}
      </span>
      {children}
      {error ? (
        <span className="field-error">
          <AlertCircle size={14} />
          {error}
        </span>
      ) : hint ? (
        <span className="field-hint">{hint}</span>
      ) : null}
    </label>
  )
}

export function Input({ error, className = "", ...props }) {
  return (
    <input
      className={`input ${error ? "input-error" : ""} ${className}`}
      aria-invalid={Boolean(error)}
      {...props}
    />
  )
}

export function Select({ error, className = "", children, ...props }) {
  return (
    <select
      className={`input select ${error ? "input-error" : ""} ${className}`}
      aria-invalid={Boolean(error)}
      {...props}
    >
      {children}
    </select>
  )
}

export function StatusBadge({ status }) {
  return (
    <span className={`status status-${status?.toLowerCase()}`}>{status}</span>
  )
}

export function RoleBadge({ role }) {
  return (
    <span className={`role-badge role-${role?.toLowerCase()}`}>{role}</span>
  )
}

export function PageHeader({ eyebrow, title, description, actions }) {
  return (
    <header className="page-header">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </header>
  )
}

export function LoadingState({ rows = 5 }) {
  return (
    <div className="skeleton-wrap" aria-label="Loading">
      {Array.from({ length: rows }).map((_, index) => (
        <div className="skeleton-row" key={index}>
          <span />
          <span />
          <span />
          <span />
        </div>
      ))}
    </div>
  )
}

export function EmptyState({ title, description, action }) {
  return (
    <div className="empty-state">
      <div className="empty-icon">
        <Inbox size={23} />
      </div>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  )
}

export function ErrorState({
  title = "Something went wrong",
  message,
  onRetry,
}) {
  return (
    <div className="error-state">
      <AlertCircle size={22} />
      <div>
        <strong>{title}</strong>
        <p>{message}</p>
      </div>
      {onRetry && (
        <Button variant="secondary" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  )
}

export function Modal({
  open,
  title,
  description,
  children,
  onClose,
  footer,
  width = "medium",
}) {
  if (!open) return null
  return (
    <div
      className="modal-backdrop"
      role="presentation"
      onMouseDown={(event) =>
        event.target === event.currentTarget && onClose?.()
      }
    >
      <section
        className={`modal modal-${width}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        <header className="modal-header">
          <div>
            <h2 id="modal-title">{title}</h2>
            {description && <p>{description}</p>}
          </div>
          <button
            className="icon-btn"
            onClick={onClose}
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </header>
        <div className="modal-body">{children}</div>
        {footer && <footer className="modal-footer">{footer}</footer>}
      </section>
    </div>
  )
}

export function SuccessMark() {
  return (
    <div className="success-mark">
      <Check size={28} />
    </div>
  )
}

export function Toast({ message, tone = "success", onClose }) {
  if (!message) return null
  return (
    <div className={`toast toast-${tone}`} role="status">
      {tone === "success" ? <Check size={17} /> : <AlertCircle size={17} />}
      <span>{message}</span>
      <button onClick={onClose} aria-label="Close">
        <X size={16} />
      </button>
    </div>
  )
}
