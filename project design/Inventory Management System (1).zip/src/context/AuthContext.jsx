import { createContext, useContext, useEffect, useState } from "react"
import { api } from "../services/api"

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("gosrani-user"))
    } catch {
      return null
    }
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (user) api.setActiveUser(user)
  }, [user])

  const login = async (credentials) => {
    setLoading(true)
    try {
      const response = await api.login(credentials)
      setUser(response.data.user)
      localStorage.setItem("gosrani-user", JSON.stringify(response.data.user))
      localStorage.setItem("gosrani-token", response.data.token)
      return response.data.user
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    api.logout()
    setUser(null)
    localStorage.removeItem("gosrani-user")
    localStorage.removeItem("gosrani-token")
  }

  return (
    <AuthContext.Provider
      value={{ user, login, logout, loading, isAdmin: user?.role === "Admin" }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
