export function formatDate(value) {
  if (!value) return "–"
  const [year, month, day] = value.slice(0, 10).split("-")
  return `${day}/${month}/${year}`
}

export function formatDateTime(value) {
  if (!value) return "–"
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
    .format(new Date(value))
    .replace(",", " at")
}

export const todayIso = () => new Date().toISOString().slice(0, 10)
